package modelo.hospital;

import modelo.personas.Medico;
import modelo.personas.Paciente;
import modelo.enums.EstadoCita;

import java.time.LocalDateTime;

public class CitaMedica {

    private Paciente paciente;
    private Medico medico;
    private LocalDateTime fecha;
    private EstadoCita estado;

    public CitaMedica(Paciente paciente, Medico medico, LocalDateTime fecha) {
        this.paciente = paciente;
        this.medico = medico;
        this.fecha = fecha;
        this.estado = EstadoCita.PENDIENTE;
    }

    public void completar() {
        estado = EstadoCita.COMPLETADA;
    }

    public void cancelar() {
        estado = EstadoCita.CANCELADA;
    }
}