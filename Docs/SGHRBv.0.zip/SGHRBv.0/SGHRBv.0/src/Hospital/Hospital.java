package modelo.hospital;

import modelo.abstractas.Empleado;
import java.util.ArrayList;
import java.util.List;

public class Hospital {

    private String nombre;
    private List<Empleado> empleados = new ArrayList<>();

    public Hospital(String nombre) {
        this.nombre = nombre;
    }

    public void contratarEmpleado(Empleado e) {
        empleados.add(e);
    }

    public double calcularNominaTotal() {
        double total = 0;
        for (Empleado e : empleados) {
            total += e.calcularSalario(); // POLIMORFISMO
        }
        return total;
    }
}