package principal;

import modelo.hospital.*;
import modelo.personas.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;

public class SistemaHospital {

    static Scanner sc = new Scanner(System.in);
    static Hospital hospital = new Hospital("Hospital Central");

    static List<Paciente> pacientes = new ArrayList<>();
    static List<Medico> medicos = new ArrayList<>();
    static List<CitaMedica> citas = new ArrayList<>();

    public static void main(String[] args) {

        int opcion;

        do {
            System.out.println("\n===== SISTEMA HOSPITALARIO =====");
            System.out.println("1. Registrar empleado");
            System.out.println("2. Registrar paciente");
            System.out.println("3. Agendar cita");
            System.out.println("4. Cambiar estado de cita");
            System.out.println("5. Ver nómina total");
            System.out.println("6. Ver pacientes");
            System.out.println("7. Ver citas");
            System.out.println("0. Salir");
            System.out.print("Seleccione: ");

            opcion = sc.nextInt();
            sc.nextLine();

            switch (opcion) {
                case 1 -> registrarEmpleado();
                case 2 -> registrarPaciente();
                case 3 -> agendarCita();
                case 4 -> cambiarEstadoCita();
                case 5 -> System.out.println("Nómina total: " + hospital.calcularNominaTotal());
                case 6 -> mostrarPacientes();
                case 7 -> mostrarCitas();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción inválida");
            }

        } while (opcion != 0);
    }

    // =========================
    // EMPLEADOS
    // =========================

    private static void registrarEmpleado() {
        System.out.println("\n1. Médico\n2. Cirujano\n3. Enfermero");
        int tipo = sc.nextInt();
        sc.nextLine();

        switch (tipo) {
            case 1 -> {
                Medico m = crearMedico();
                hospital.contratarEmpleado(m);
                medicos.add(m);
            }
            case 2 -> {
                Cirujano c = crearCirujano();
                hospital.contratarEmpleado(c);
                medicos.add(c);
            }
            case 3 -> hospital.contratarEmpleado(crearEnfermero());
        }
    }

    // =========================
    // PACIENTES
    // =========================

    private static void registrarPaciente() {

        System.out.println("\n--- REGISTRAR PACIENTE ---");

        System.out.print("ID: ");
        String id = sc.nextLine();

        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        System.out.print("Apellido: ");
        String apellido = sc.nextLine();

        System.out.print("Año nacimiento: ");
        int anio = sc.nextInt();
        System.out.print("Mes: ");
        int mes = sc.nextInt();
        System.out.print("Día: ");
        int dia = sc.nextInt();
        sc.nextLine();

        System.out.print("Email: ");
        String email = sc.nextLine();

        System.out.print("Grupo sanguíneo: ");
        String grupo = sc.nextLine();

        Paciente p = new Paciente(id, nombre, apellido,
                LocalDate.of(anio, mes, dia), email, grupo);

        pacientes.add(p);

        System.out.println("Paciente registrado ✔");
    }

    private static void mostrarPacientes() {
        for (int i = 0; i < pacientes.size(); i++) {
            System.out.println(i + " - " + pacientes.get(i).getNombre());
        }
    }

    // =========================
    // CITAS
    // =========================

    private static void agendarCita() {

        if (pacientes.isEmpty() || medicos.isEmpty()) {
            System.out.println("Debe haber pacientes y médicos registrados");
            return;
        }

        System.out.println("\nSeleccione paciente:");
        mostrarPacientes();
        int pIndex = sc.nextInt();

        System.out.println("Seleccione médico:");
        for (int i = 0; i < medicos.size(); i++) {
            System.out.println(i + " - " + medicos.get(i).getNombre());
        }
        int mIndex = sc.nextInt();

        System.out.print("Año: ");
        int anio = sc.nextInt();
        System.out.print("Mes: ");
        int mes = sc.nextInt();
        System.out.print("Día: ");
        int dia = sc.nextInt();
        System.out.print("Hora: ");
        int hora = sc.nextInt();
        sc.nextLine();

        CitaMedica cita = new CitaMedica(
                pacientes.get(pIndex),
                medicos.get(mIndex),
                LocalDateTime.of(anio, mes, dia, hora, 0)
        );

        citas.add(cita);

        System.out.println("Cita agendada ✔");
    }

    private static void mostrarCitas() {
        for (int i = 0; i < citas.size(); i++) {
            System.out.println(i + " - Estado: " + citas.get(i));
        }
    }

    private static void cambiarEstadoCita() {

        if (citas.isEmpty()) {
            System.out.println("No hay citas");
            return;
        }

        mostrarCitas();
        System.out.print("Seleccione cita: ");
        int index = sc.nextInt();

        System.out.println("1. Completar\n2. Cancelar");
        int opcion = sc.nextInt();

        if (opcion == 1) citas.get(index).completar();
        else citas.get(index).cancelar();

        System.out.println("Estado actualizado ✔");
    }

    // =========================
    // CREACIÓN DE OBJETOS
    // =========================

    private static Medico crearMedico() {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        return new Medico("1", nombre, "X",
                LocalDate.of(1990,1,1), "mail",
                "M1", LocalDate.now(), 2000, "General");
    }

    private static Cirujano crearCirujano() {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        return new Cirujano("2", nombre, "X",
                LocalDate.of(1985,1,1), "mail",
                "C1", LocalDate.now(), 3000,
                "Cirugía", 5);
    }

    private static Enfermero crearEnfermero() {
        System.out.print("Nombre: ");
        String nombre = sc.nextLine();

        return new Enfermero("3", nombre, "X",
                LocalDate.of(1995,1,1), "mail",
                "E1", LocalDate.now(), 1500, "DIA");
    }
}
