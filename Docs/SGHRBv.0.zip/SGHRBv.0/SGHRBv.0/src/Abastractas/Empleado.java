package modelo.abstractas;

import java.time.LocalDate;
import java.time.Period;

public abstract class Empleado extends Persona {

    private String legajo;
    private LocalDate fechaContratacion;
    private double salarioBase;
    private boolean activo;

    public Empleado(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                    String legajo, LocalDate fechaContratacion, double salarioBase) {
        super(id, nombre, apellido, fechaNacimiento, email);
        this.legajo = legajo;
        this.fechaContratacion = fechaContratacion;
        setSalarioBase(salarioBase);
        this.activo = true;
    }

    public int antiguedad() {
        return Period.between(fechaContratacion, LocalDate.now()).getYears();
    }

    public abstract double calcularSalario();

    public double getSalarioBase() {
        return salarioBase;
    }

    public void setSalarioBase(double salarioBase) {
        if (salarioBase <= 0) throw new IllegalArgumentException("Salario inválido");
        this.salarioBase = salarioBase;
    }
}