package modelo.personas;

import java.time.LocalDate;

public class Cirujano extends Medico {

    private int cirugiasRealizadas;

    public Cirujano(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                    String legajo, LocalDate fechaContratacion, double salarioBase,
                    String especialidad, int cirugiasRealizadas) {

        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase, especialidad);
        this.cirugiasRealizadas = cirugiasRealizadas;
    }

    @Override
    public double calcularSalario() {
        return super.calcularSalario() + (cirugiasRealizadas * 200);
    }

    @Override
    public String obtenerTipo() {
        return "Cirujano";
    }
}