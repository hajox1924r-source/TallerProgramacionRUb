package modelo.personas;

import modelo.abstractas.Empleado;
import java.time.LocalDate;

public class Enfermero extends Empleado {

    private String turno;

    public Enfermero(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                     String legajo, LocalDate fechaContratacion, double salarioBase, String turno) {

        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        this.turno = turno;
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase() + (turno.equals("NOCHE") ? 300 : 100);
    }

    @Override
    public String obtenerTipo() {
        return "Enfermero";
    }
}