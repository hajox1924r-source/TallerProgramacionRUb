package modelo.personas;

import modelo.abstractas.Empleado;
import java.time.LocalDate;

public class Medico extends Empleado {

    private String especialidad;

    public Medico(String id, String nombre, String apellido, LocalDate fechaNacimiento, String email,
                  String legajo, LocalDate fechaContratacion, double salarioBase, String especialidad) {

        super(id, nombre, apellido, fechaNacimiento, email, legajo, fechaContratacion, salarioBase);
        this.especialidad = especialidad;
    }

    @Override
    public double calcularSalario() {
        return getSalarioBase() + (antiguedad() * 100);
    }

    @Override
    public String obtenerTipo() {
        return "Médico";
    }
}